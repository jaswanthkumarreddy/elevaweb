=== Elevaweb ===
Contributors: Mercado Binário
Tags: publication, automation, autopost, postagem, marketing, e-mail, automação, publicação
Requires at least: ??????
Tested up to: ??????
Stable tag: 0.1
License: free

English: Your site with more visits and relevant content automatically posted on your wordpress blog.

Portuguese (pt_BR): Seu site com mais visitas e conteúdo relevante postado automaticamente no seu blog wordpress.

== Description ==
English: Increase your traffic. With the automation robot Elevaweb you will have more than one site with content, you will have movement, more people accessing and getting on your site. After testing the beta we will launch the posting features in social networks and email marketing.
You can now have more visits on your site with content from our partners automatically posted to your blog.

Portuguese (pt_BR): Aumente suas visitas. Com o robô de automação Elevaweb você vai ter mais do que um site com conteúdo, você terá movimento, mais gente acessando e ficando no seu site. Após o teste da versão beta vamos lançar os recursos de postagem nas redes sociais e e-mail marketing. 
Agora você pode ter mais visitas no seu site com conteúdo de nossos parceiros postado automaticamente no seu blog.

== Installation ==
English: 
[Install Elevaweb from our site](https://elevaweb.com.br?from=wporg) by typing in your site address.

Alternatively install Elevaweb via the plugin directory, or by uploading the files manually to your server. After activating Elevaweb, create your account or connect to enable the Elevaweb features.

Portuguese (pt_BR): 
[Instale o robô Elevaweb do nosso site] (https://elevaweb.com.br?from=wporg) digitando o endereço do site.

Em alternativa, instale o robô Elevaweb através do directório de plugins ou carregue os ficheiros manualmente no servidor. Depois de ativar o Elevaweb, crie sua conta ou conecte-se para ativar os recursos do Elevaweb.

== Screenshots ==
1. Auto Post configuration
2. Elevaweb Dashboard
3. My auto posts
4. Register
5. Login
6. Forgot Password