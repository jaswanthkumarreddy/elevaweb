<?php

namespace InstagramAPI;

class InstagramException extends \Exception
{
}
